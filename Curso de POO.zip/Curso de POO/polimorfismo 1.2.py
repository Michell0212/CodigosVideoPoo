num1 = 3
num2 = 4.4

resultado = num1 + num2 

print(resultado)
print(type(resultado))
