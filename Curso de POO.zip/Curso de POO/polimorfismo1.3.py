def recorrer(elemento):
    for item in elemento:
        print(f"El elemento actual es {item}")


lista1 = [1,2,3,4]
lista2 = ["maquina", "como","andas" ]

recorrer(lista1)
  